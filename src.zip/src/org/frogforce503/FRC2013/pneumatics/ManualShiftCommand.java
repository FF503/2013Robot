package org.frogforce503.FRC2013.pneumatics;

import edu.wpi.first.wpilibj.command.Command;
import org.frogforce503.FRC2013.pneumatics.Shifter.Position;


/**
 *
 * @author Bryce Paputa
 */
public class ManualShiftCommand extends Command {
    private final Position position;

    public ManualShiftCommand(Position pos) {
        // Use requires() here to declare subsystem dependencies
        // eg. requires(chassis);
        
        position = pos;
        requires(Shifter.getInstance());
        setTimeout(.5d);
        setInterruptible(false);
    }

    // Called just before this Command runs the first time
    protected void initialize() {
        Shifter.manualShift(position);
    }

    // Called repeatedly when this Command is scheduled to run
    protected void execute() {
    }

    // Make this return true when this Command no longer needs to run execute()
    protected boolean isFinished() {
        return isTimedOut();
    }

    // Called once after isFinished returns true
    protected void end() {
        //new AutoShiftCommand().start();
    }

    // Called when another command which requires one or more of the same
    // subsystems is scheduled to run
    protected void interrupted() {
    }
}
