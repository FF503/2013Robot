package org.frogforce503.FRC2013;


/**
 * The RobotMap is a mapping from the ports sensors and actuators are wired into
 * to a variable name. This provides flexibility changing wiring, makes checking
 * the wiring easier and significantly reduces the number of magic numbers
 * floating around.
 */
public interface RobotMap {
    public static final int DRIVER_PORT = 1,
                            LEFTX = 1,
                            LEFTY = 2,
                            RIGHTX = 4,
                            RIGHTY = 5,
                            DPADX = 6,
                                //PWM
                            DRIVETRAIN_LEFT_FRONT_MOTOR_CHANNEL = 1, 
                            DRIVETRAIN_LEFT_BACK_MOTOR_CHANNEL = 2, 
                            DRIVETRAIN_RIGHT_FRONT_MOTOR_CHANNEL = 3, 
                            DRIVETRAIN_RIGHT_BACK_MOTOR_CHANNEL = 4,
                            SHOOTER_MOTOR_CHANNEL = 5,
                            SHOOTER_ANGLER_CHANNEL = 6,
                            //CLIMBER_MOTOR_CHANNEL = 7,
                                //GPIO
                            DRIVETRAIN_LEFT_ENCODER_CHANNEL_A = 1,
                            DRIVETRAIN_LEFT_ENCODER_CHANNEL_B = 2,
                            DRIVETRAIN_RIGHT_ENCODER_CHANNEL_A = 3,
                            DRIVETRAIN_RIGHT_ENCODER_CHANNEL_B = 4,
                            PNEUMATICS_PRESURE_SWITCH_CHANNEL = 5,
                            SHOOTER_GEAR_TOOTH_SENSOR_CHANNEL = 7,
                            SHOOTER_ANGLER_LOWER_LIMIT_SWITCH_CHANNEL = 8,
                            SHOOTER_ANGLER_ENCODER_A_CHANNEL = 9,
                            SHOOTER_ANGLER_ENCODER_B_CHANNEL = 10,
                                //RELAYS
                            CAMERA_LIGHT_CHANNEL = 4,
                            SHOOTER_GEAR_TOOTH_SENSOR_POWER_CHANNEL = 1,
                            PNEUMATICS_COMPRESSOR_CHANNEL = 2,
                                //SOLENOIDS
                            SHOOTER_FIRING_MECHANISM_FORWARD_CHANNEL = 1,
                            DRIVETRAIN_SHIFTER_CHANNEL = 2,
                                //3 is broken
                            CLIMBER_CLIMB_DOWN_CHANNEL = 4,
                            CLIMBER_CLIMB_UP_CHANNEL = 5,
            
                                //ANALOG INPUT
                            SHOOTER_ANGLER_POT_CHANNEL = 1;    
}
 