package org.frogforce503.FRC2013.shooter;

import edu.wpi.first.wpilibj.command.CommandGroup;
import org.frogforce503.FRC2013.angler.GotoAngleCommand;
import org.frogforce503.FRC2013.shooter.Shooter.ShooterPosition;


/**
 *
 * @author Bryce Paputa
 */
public class GoToPositionCommandGroup extends CommandGroup {
    

    public GoToPositionCommandGroup(ShooterPosition pos) {
        addParallel(new SetShooterSpeedCommand(pos.getSpeed()));
        addParallel(new GotoAngleCommand(pos.getAngle()));
        addParallel(new SetShooterStateCommand(pos.getSpeed()>0?true:false));
    }
}
