package org.frogforce503.FRC2013.shooter;

import edu.wpi.first.wpilibj.Counter;
import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.GearTooth;
import edu.wpi.first.wpilibj.Relay;
import edu.wpi.first.wpilibj.Relay.Value;
import edu.wpi.first.wpilibj.Solenoid;
import edu.wpi.first.wpilibj.Talon;
import edu.wpi.first.wpilibj.command.Subsystem;
import edu.wpi.first.wpilibj.livewindow.LiveWindow;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import java.util.Timer;
import java.util.TimerTask;
import org.frogforce503.FRC2013.RobotMap;

/**
 *
 * @author Bryce Paputa
 */

//DATA:
//distance (ft)     angle (robot)   angle (phone)
//18                18.5            15
//15                20.5            17.5
//21                16.5            14
//24                17              13
//

public class Shooter extends Subsystem{
    public static class ShooterPosition{
        final private double angle, speed;
        private ShooterPosition(double angle, double speed){
            this.angle = angle;
            this.speed = speed;
        }
        public double getAngle(){
            return angle;
        }
        public double getSpeed(){
            return speed;
        }
        final public static ShooterPosition FRONT_LEG = new ShooterPosition(27, 3500);//3500
        final public static ShooterPosition BACK_LEG = new ShooterPosition(18, 3500);//3500
        final public static ShooterPosition BACK_BAR = new ShooterPosition(23, 3000);//3000
        final public static ShooterPosition LOADING = new ShooterPosition(0, 0);//0
        final public static ShooterPosition FAR = new ShooterPosition(5.5, 4500);//4500
    }
    
    private static final Talon shooter = new Talon(RobotMap.SHOOTER_MOTOR_CHANNEL);
    
    //private static final Counter counter = new Counter(RobotMap.SHOOTER_ENCODER_PORT_A);
    
    private static final Counter gt = new GearTooth(RobotMap.SHOOTER_GEAR_TOOTH_SENSOR_CHANNEL);
    
    private static final Relay gtRelay = new Relay(RobotMap.SHOOTER_GEAR_TOOTH_SENSOR_POWER_CHANNEL);
    
   // private static final Encoder encoder = new Encoder(RobotMap.SHOOTER_ENCODER_PORT_A, RobotMap.SHOOTER_ENCODER_PORT_B, false, CounterBase.EncodingType.k1X);
    
    private static final Solenoid firingMechanism = new Solenoid(RobotMap.SHOOTER_FIRING_MECHANISM_FORWARD_CHANNEL);
    
    static{
        LiveWindow.addActuator("Shooter", "Motor", shooter);        
        LiveWindow.addSensor("Shooter", "gt", gt);
        LiveWindow.addSensor("Shooter", "gtRelay", gtRelay);
        gt.start();
        
        gtRelay.set(Value.kForward);
        shooter.setSafetyEnabled(false);
    }
    
    //private static final Encoder encoder = new Encoder(RobotMap.SHOOTER_ENCODER_A_PORT, 
    //                                                    RobotMap.SHOOTER_ENCODER_B_PORT);
    private static final int NUM_SAMPLES = 10;
    private static double targetSpeed = 1000;
    public static final double SPINUP_SPEED = 0;
    public static final double SPINUP_OUTPUT = .5;
    private static final double PERCENT_THRESHOLD = .02;
    
    private static boolean isOn = false;
    
    //private static double lastTime = edu.wpi.first.wpilibj.Timer.getFPGATimestamp();
    private static double avgSpeed = 0;
    
    private Shooter(){}
    
    private static Shooter instance = new Shooter();
    
    private static double getRawSpeed(){
        //return encoder.getRate();
        double measuredRPM = 1/gt.getPeriod()*60 /6d * 66d/32d;
        avgSpeed = avgSpeed / (NUM_SAMPLES) * (NUM_SAMPLES - 1) + measuredRPM / (NUM_SAMPLES);
        return measuredRPM;
    }
    
    public static double getAvgSpeed(){
        return avgSpeed;
    }
    
    public static void setTargetSpeed(double speed){
        targetSpeed = speed;
    }
    
    public static void setSpeed(double speed){
        shooter.set(speed);
    }
    
    public static boolean onTarget(){
        return Math.abs(avgSpeed-targetSpeed)/targetSpeed < PERCENT_THRESHOLD;
    }
    
    private static final TimerTask SpeedTask = new TimerTask(){
        double avgOutput = 0;
        double outputAvgSamples = 10;
        public void run() {
            if(isOn()&& DriverStation.getInstance().isEnabled()){
                //targetSpeed = SmartDashboard.getNumber("Target Speed");
                double speed = getRawSpeed(), output = 0;
                if(isOn() && (speed < SPINUP_SPEED)){
                    output = SPINUP_OUTPUT;//                    SmartDashboard.putNumber("Shooter Output", SPINUP_OUTPUT);
                } else 
                if(isOn() && (speed < targetSpeed)){
                    output = 1;
                }
                setSpeed(output);
                SmartDashboard.putNumber("Shooter Output", output);
                SmartDashboard.putNumber("gear tooth speed graph", speed);
                SmartDashboard.putNumber("gear tooth speed view", speed);
                avgOutput = avgOutput / (outputAvgSamples) * (outputAvgSamples - 1) + output / (outputAvgSamples);
                SmartDashboard.putNumber("avg output", avgOutput);
                double avgSpeed = getAvgSpeed();
                SmartDashboard.putNumber("avg speed graph", avgSpeed);
                SmartDashboard.putNumber("avg speed view", avgSpeed);
                //SmartDashboard.putNumber("target speed", targetSpeed);
            }
//            else {
//                SmartDashboard.putNumber("Target Speed", 0);
//            }
        }        
    };
    
    private static final long SPEED_TASK_PERIOD = 60;
    private static final Timer timer = new Timer();

    static{
        timer.schedule(SpeedTask, 0, SPEED_TASK_PERIOD);
    }

    public static Shooter getInstance() {
        return instance;
    }


    protected void initDefaultCommand() {
    }
    
    public static boolean isOn(){
        return isOn;
    }
    
    public static void setOn(boolean state) {
        isOn = state;
        gtRelay.set(Value.kForward);
        SmartDashboard.putBoolean("shooter state", state);
        shooter.set(0);
    }
    
    public static void extendFiringMechanism(){
        firingMechanism.set(false);
    }
    
    public static void retractFiringMechanism(){
        firingMechanism.set(true);
    }
    
    private static int numFrisbees = -1;
    
    public static void resetNumFrisbees(int num){
        numFrisbees = num;
    }
    
    public static void decrementNumFrisbees(){
        numFrisbees--;
    }
    
    public static double getNumFrisbees(){
        return numFrisbees;
    }
}