package org.frogforce503.FRC2013.util.limitSwitches;


/**
 *
 * @author Bryce Paputa
 */
public class DualLimitSwitchSystem implements LimitSwitchSystem{
    public NCLimitSwitch lowerLimitSwitch, upperLimitSwitch;
    public DualLimitSwitchSystem(NCLimitSwitch lower, NCLimitSwitch upper){
        lowerLimitSwitch = lower;
        upperLimitSwitch = upper;
    }
    
    public LimitSwitchState getLimitSwitchState(){
        boolean lower = lowerLimitSwitch.get(), upper = upperLimitSwitch.get();
        if(!lower && !upper){
            
            return LimitSwitchState.UNTRIGGERED;
        } else if(lower && !upper){
            return LimitSwitchState.LOWER;
        } else if (upper && !lower){
            return LimitSwitchState.UPPER;
        }
        return LimitSwitchState.ERROR;
    }
    
    public boolean canGoUp(){
        LimitSwitchState state = getLimitSwitchState();
        return state == LimitSwitchState.LOWER || state == LimitSwitchState.UNTRIGGERED;
    }
    
    public boolean canGoDown(){
        LimitSwitchState state = getLimitSwitchState();
        return state == LimitSwitchState.UPPER || state == LimitSwitchState.UNTRIGGERED;
    }
    
}
