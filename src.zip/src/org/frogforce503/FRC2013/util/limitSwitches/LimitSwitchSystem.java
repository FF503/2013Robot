package org.frogforce503.FRC2013.util.limitSwitches;


/**
 *
 * @author Bryce Paputa
 */
public interface LimitSwitchSystem {
    public boolean canGoUp();
    
    public boolean canGoDown();
    
}
