package org.frogforce503.FRC2013.util.limitSwitches;


/**
 *
 * @author Bryce Paputa
 */
public final class LimitSwitchState {
    private static final int ERROR_VAL = -1;
    private static final int UNTRIGGERED_VAL = 0;
    private static final int LOWER_VAL = 1;
    private static final int UPPER_VAL = 2;
    private final int value;

    private LimitSwitchState(int val) {
        value = val;
    }
    public static final LimitSwitchState ERROR = new LimitSwitchState(ERROR_VAL);
    public static final LimitSwitchState UNTRIGGERED = new LimitSwitchState(UNTRIGGERED_VAL);
    public static final LimitSwitchState LOWER = new LimitSwitchState(LOWER_VAL);
    public static final LimitSwitchState UPPER = new LimitSwitchState(UPPER_VAL);
    
}
