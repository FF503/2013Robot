package org.frogforce503.FRC2013.util.limitSwitches;


/**
 *
 * @author Bryce Paputa
 */
public class SingleLimitSwitchSystem implements LimitSwitchSystem{
    public final NCLimitSwitch lowerLimitSwitch;
    public SingleLimitSwitchSystem(NCLimitSwitch lower){
        lowerLimitSwitch = lower;
    }
    
    public LimitSwitchState getLimitSwitchState(){
        boolean lower = lowerLimitSwitch.get();
        if(!lower){
            return LimitSwitchState.UNTRIGGERED;
        } else if(lower){
            return LimitSwitchState.LOWER;
        }
        return LimitSwitchState.ERROR;
    }
    
    public boolean canGoUp(){
        return true;
    }
    
    public boolean canGoDown(){
        LimitSwitchState state = getLimitSwitchState();
        return state == LimitSwitchState.UNTRIGGERED;
    }
}
