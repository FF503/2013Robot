package org.frogforce503.FRC2013.util.calibrations;

//import com.sun.squawk.microedition.io.FileConnection;
import edu.wpi.first.wpilibj.PIDSource;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
//import java.io.DataInputStream;
//import java.io.DataOutputStream;
//import javax.microedition.io.Connector;




/**
 *
 * @author Bryce Paputa
 */
public abstract class LinearCalibration implements PIDSource{
    private boolean isCalibrated = false;
    private double m;
    private double b;
    private double vLow = 0;
    private double vHigh = 0;
    public final double LOWER_DISTANCE;
    public final double UPPER_DISTANCE;
    public final String name;
    public LinearCalibration(double lowerDistance, double upperDistance, String name){
        LOWER_DISTANCE = lowerDistance;
        UPPER_DISTANCE = upperDistance;
        this.name = name;
    }
    
    public void setLowerPoint() {
        vLow = getVoltage();
        SmartDashboard.putNumber("vLow", vLow);
        recalibrate();
    }
    
    public void setUpperPoint() {
        vHigh = getVoltage();
        SmartDashboard.putNumber("vHigh", vHigh);
        recalibrate();
    }

    public void recalibrate() {
        if(vLow - vHigh == 0) {
            vLow += 1.0E-4;
        }
        m = (LOWER_DISTANCE - UPPER_DISTANCE) / (vLow - vHigh);
        b = UPPER_DISTANCE - m * vHigh;
        isCalibrated = true;
        SmartDashboard.putNumber("m", m);
        SmartDashboard.putNumber("b", b);
    }

    public boolean isCalibrated() {
        return isCalibrated;
    }

    public double getDistanceFromVoltage(double v) {
        
        return m * v + b;
    }

    public abstract double getUsableVariableFromDistance(double d);
    
    public abstract double getVoltage();

    public double pidGet() {
        return getUsableVariableFromDistance(getDistanceFromVoltage(getVoltage()));
    }
    /*
    public void saveToFile(){
        if(isCalibrated){
            DataOutputStream bOutputStream, mOutputStream;
            FileConnection fcm, fcb;
            try {
                fcm = (FileConnection)Connector.open("file:///"+name+"_m", Connector.WRITE);
                fcb = (FileConnection)Connector.open("file:///"+name+"_b", Connector.WRITE);

                fcm.create();
                fcb.create();

                mOutputStream = fcm.openDataOutputStream();
                bOutputStream = fcb.openDataOutputStream();

                mOutputStream.writeDouble(m);
                bOutputStream.writeDouble(b);

                try{
                    mOutputStream.close();
                    bOutputStream.close();
                } finally{
                    try{
                        fcm.close();
                        fcb.close();
                    } catch(Exception e) {}
                }
                
                isCalibrated = true;
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        } else {
            System.err.println("Cannot save calibration to file before calibrating.");
        }
    }
    
    public void readFromFile(){
        DataInputStream bInputStream, mInputStream;
        FileConnection fcm, fcb;
        try {
            fcm = (FileConnection)Connector.open("file:///"+name+"_m", Connector.READ);
            fcb = (FileConnection)Connector.open("file:///"+name+"_b", Connector.READ);

            if(!fcm.exists() || !fcb.exists()){
                throw new Exception("Cannot read from file because it does not exist.");
            }
            
            mInputStream = fcm.openDataInputStream();
            bInputStream = fcb.openDataInputStream();

            m = mInputStream.readDouble();
            b = bInputStream.readDouble();

            try{
                mInputStream.close();
                bInputStream.close();
            } finally{
                try{
                    fcm.close();
                    fcb.close();
                } catch(Exception e) {}
            }

            isCalibrated = true;
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }*/
}
