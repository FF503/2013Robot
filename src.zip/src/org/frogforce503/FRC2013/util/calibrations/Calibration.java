package org.frogforce503.FRC2013.util.calibrations;

import edu.wpi.first.wpilibj.PIDSource;



/**
 *
 * @author Bryce Paputa
 */
public interface Calibration extends PIDSource{
    public void setLowerPoint();
    public void setUpperPoint();
    public double get();
    public boolean isCalibrated();
}
