package org.frogforce503.FRC2013;

import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.buttons.JoystickButton;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import org.frogforce503.FRC2013.angler.Angler;
import org.frogforce503.FRC2013.angler.AutoCalibrateAnglerCommandGroup;
import org.frogforce503.FRC2013.angler.GoBackToAngleCommand;
import org.frogforce503.FRC2013.drivetrain.Drivetrain;
import org.frogforce503.FRC2013.pneumatics.AutoShiftCommand;
import org.frogforce503.FRC2013.pneumatics.Compressor;
import org.frogforce503.FRC2013.pneumatics.ManualShiftCommand;
import org.frogforce503.FRC2013.pneumatics.Shifter;
import org.frogforce503.FRC2013.shooter.GoToPositionCommandGroup;
import org.frogforce503.FRC2013.shooter.LaunchCommandGroup;
import org.frogforce503.FRC2013.shooter.SetShooterStateCommand;
import org.frogforce503.FRC2013.shooter.Shooter;
import org.frogforce503.FRC2013.shooter.Shooter.ShooterPosition;

/**
 * This class is the glue that binds the controls on the physical operator
 * interface to the commands and command groups that allow control of the robot.
 * @author Bryce Paputa
 */
public class OI {
    
    /**
     * Objects representing physical joysticks.
     */
    public static final Joystick leftStick, rightStick, operatorStick;
    public final static JoystickButton upShiftButton, downShiftButton, autoShiftButton;
    public static final JoystickButton rotButton, operatorOverRideButton;// upShiftButton, downShiftButton, 
    public static final JoystickButton farButton, backOfPyramidAngleButton, frontOfPyramidAngleButton, backBarButton, loadButton;
    public final static JoystickButton shooterOffButton, shooterFireButton, autoCalibrateAnglerButton;
    public final static JoystickButton goBackToAngleButton;
    public static final int DRIVER_PORT = 1;
    public static final int LEFTX = 1;
    public static final int LEFTY = 2;
    public static final int RIGHTX = 3;
    public static final int RIGHTY = 4;
    public static final int DPADX = 5;
    /*
     * Static block that initializes the joysticks and buttons and 
     * puts the commands to the SmartDashboard.
     */
    static {
        SmartDashboard.putData(Drivetrain.getInstance());
        SmartDashboard.putData(Shooter.getInstance());
        SmartDashboard.putData(Shifter.getInstance());
        SmartDashboard.putData(Compressor.getInstance());
        SmartDashboard.putData(Angler.getInstance());
        //SmartDashboard.putData(Scheduler.getInstance());
            //create the joystick objects
        leftStick = new Joystick(1);
        rightStick = new Joystick(2);
        operatorStick = new Joystick(3);
        shooterOffButton = new JoystickButton(operatorStick, 7);
        shooterOffButton.whenPressed(new SetShooterStateCommand(false));
        
        
        shooterFireButton = new JoystickButton(operatorStick, 6);
        //shooterFireButton.whenPressed(new LaunchCommandGroup());
        shooterFireButton.whileHeld(new LaunchCommandGroup());
        rotButton = new JoystickButton(rightStick, 1);
        autoCalibrateAnglerButton = new JoystickButton(operatorStick, 5);
        autoCalibrateAnglerButton.whenPressed(new AutoCalibrateAnglerCommandGroup());
        
        backOfPyramidAngleButton = new JoystickButton(operatorStick, 1);
        backOfPyramidAngleButton.whileHeld(new GoToPositionCommandGroup(ShooterPosition.BACK_LEG));
        frontOfPyramidAngleButton = new JoystickButton(operatorStick, 4);
        frontOfPyramidAngleButton.whileHeld(new GoToPositionCommandGroup(ShooterPosition.FRONT_LEG));
        backBarButton = new JoystickButton(operatorStick, 2);
        backBarButton.whileHeld(new GoToPositionCommandGroup(ShooterPosition.BACK_BAR));
        loadButton = new JoystickButton(operatorStick, 3);
        loadButton.whileHeld(new GoToPositionCommandGroup(ShooterPosition.LOADING));
        farButton = new JoystickButton(operatorStick, 10);
        farButton.whileHeld(new GoToPositionCommandGroup(ShooterPosition.FAR));
        goBackToAngleButton = new JoystickButton(operatorStick, 9);
        goBackToAngleButton.whileHeld(new GoBackToAngleCommand());
        operatorOverRideButton = new JoystickButton(operatorStick, 8);
        
        upShiftButton = new JoystickButton(rightStick, 3);
        downShiftButton = new JoystickButton(rightStick, 2);
        autoShiftButton = new JoystickButton(rightStick, 4);
        upShiftButton.whenPressed(new ManualShiftCommand(Shifter.Position.UP));
        downShiftButton.whenPressed(new ManualShiftCommand(Shifter.Position.DOWN));
        autoShiftButton.whenPressed(new AutoShiftCommand());
        
                //put the commands to the SmartDashboard
        //xError            Rotation
        //.248              -1.057
        //.24               .976
        //.13               .77
        //.065              .266 far
        //
        //.03               .195
    }   //.249              1
        //.1                .388 close
    /**
     * Gets the left drive input.
     * @return left drive input
     */
    public static double getLeftDriveInput(){
        return -leftStick.getY();
    }
    
    /**
     * Gets the right drive input.
     * @return right drive input
     */
    public static double getRightDriveInput(){
        return -rightStick.getY();
    }
    
    public static double getRotInput(){
        return -rightStick.getX();
    }
            
    public static double getSpeedInput(){
        return -rightStick.getY();
    }
    
    public static double getOperatorRotInput(){
        return -operatorStick.getRawAxis(RIGHTX);
    }
    
    public static boolean getOperatorOverRide(){
        return operatorOverRideButton.get();
    }
    
    public static double getAngleInput(){
        return operatorStick.getY();
    }
}

