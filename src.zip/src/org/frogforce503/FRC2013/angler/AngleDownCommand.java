package org.frogforce503.FRC2013.angler;

import edu.wpi.first.wpilibj.command.Command;



/**
 *
 * @author Bryce Paputa
 */
public class AngleDownCommand extends Command {
    private boolean done = false;
    private final double speed;
    
    public AngleDownCommand(double speed) {
        // Use requires() here to declare subsystem dependencies
        // eg. requires(chassis);
        requires(Angler.getInstance());
        this.speed = speed;
    }

    public AngleDownCommand(double speed, double time){
        requires(Angler.getInstance());
        setTimeout(time);
        this.speed = speed;
    }
    
    // Called just before this Command runs the first time
    protected void initialize() {
        Angler.controller.disablePID();
        
    }

    // Called repeatedly when this Command is scheduled to run
    protected void execute() {
        done = Angler.controller.goDown(speed);
    }

    // Make this return true when this Command no longer needs to run execute()
    protected boolean isFinished() {
        return done || isTimedOut();
    }

    // Called once after isFinished returns true
    protected void end() {
    }

    // Called when another command which requires one or more of the same
    // subsystems is scheduled to run
    protected void interrupted() {
    }
}
