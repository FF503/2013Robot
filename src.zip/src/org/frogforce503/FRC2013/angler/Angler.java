package org.frogforce503.FRC2013.angler;

import edu.wpi.first.wpilibj.Encoder;
import edu.wpi.first.wpilibj.Talon;
import edu.wpi.first.wpilibj.command.Subsystem;
import org.frogforce503.FRC2013.RobotMap;
import org.frogforce503.FRC2013.util.calibrations.EncoderCalibration;
import org.frogforce503.FRC2013.util.controllers.EncoderPIDController;
import org.frogforce503.FRC2013.util.limitSwitches.NCLimitSwitch;
import org.frogforce503.FRC2013.util.limitSwitches.SingleLimitSwitchSystem;


/**
 *
 * @author Bryce Paputa
 */
public class Angler extends Subsystem {
    // Put methods for controlling this subsystem
    // here. Call these from Commands.
    private final static Talon motor = new Talon(RobotMap.SHOOTER_ANGLER_CHANNEL);
    private final static Encoder encoder = new Encoder(1,RobotMap.SHOOTER_ANGLER_ENCODER_A_CHANNEL,1, RobotMap.SHOOTER_ANGLER_ENCODER_B_CHANNEL,false, Encoder.EncodingType.k4X);
    private final static NCLimitSwitch lowerLimitSwitch = new NCLimitSwitch(RobotMap.SHOOTER_ANGLER_LOWER_LIMIT_SWITCH_CHANNEL);
    private final static SingleLimitSwitchSystem limitSwitchSystem = new SingleLimitSwitchSystem(lowerLimitSwitch);
    private final static EncoderCalibration calibration = new EncoderCalibration(encoder);
    private final static double p = 0.1, i = 0.006, d = 0;
    static {
        encoder.setDistancePerPulse(1);
    }
    private Angler(){}
    public final static EncoderPIDController controller = new  EncoderPIDController(motor, limitSwitchSystem, encoder, calibration, p, i, d);
    
    private final static Angler instance = new Angler();
    
    public static Angler getInstance(){
        return instance;
    }
    
    public void initDefaultCommand() {
        // Set the default command for a subsystem here.
        //setDefaultCommand(new MySpecialCommand());
        setDefaultCommand(new ManualAngleCommand());
    }

    
}
