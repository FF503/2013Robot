package org.frogforce503.FRC2013.angler;

import edu.wpi.first.wpilibj.command.Command;



/**
 *
 * @author Bryce Paputa
 */
public class GotoAngleCommand extends Command {
    private final double angle;

    public GotoAngleCommand(double angle) {
        // Use requires() here to declare subsystem dependencies
        // eg. requires(chassis);
        requires(Angler.getInstance());
        this.angle = angle;
    }

    // Called just before this Command runs the first time
    protected void initialize() {
        Angler.controller.setPIDSetpoint(angle);
        Angler.controller.enablePID();
    }

    // Called repeatedly when this Command is scheduled to run
    protected void execute() {
    }

    // Make this return true when this Command no longer needs to run execute()
    protected boolean isFinished() {
        return Angler.controller.isPIDOnTarget();
    }

    // Called once after isFinished returns true
    protected void end() {
        Angler.controller.disablePID();
    }

    // Called when another command which requires one or more of the same
    // subsystems is scheduled to run
    protected void interrupted() {
        Angler.controller.disablePID();
    }
}
