/*----------------------------------------------------------------------------*/
/* Copyright (c) FIRST 2008. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package org.frogforce503.FRC2013;


import edu.wpi.first.wpilibj.IterativeRobot;
import edu.wpi.first.wpilibj.command.CommandGroup;
import edu.wpi.first.wpilibj.command.Scheduler;
import edu.wpi.first.wpilibj.livewindow.LiveWindow;
import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import org.frogforce503.FRC2013.angler.Angler;
import org.frogforce503.FRC2013.autonomous.BackBarAutonGroup;
import org.frogforce503.FRC2013.autonomous.BackLegAutonGroup;
import org.frogforce503.FRC2013.autonomous.FrontLegAutonGroup;
import org.frogforce503.FRC2013.drivetrain.Drivetrain;
import org.frogforce503.FRC2013.pneumatics.StartCompressorCommand;
import org.frogforce503.FRC2013.util.PrintSpeedCommand;
import org.frogforce503.FRC2013.util.ResetEncodersCommand;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the IterativeRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class FF503Robot extends IterativeRobot {

//    Command autonomousCommand;

    /**
     * This function is run when the robot is first started up and should be
     * used for any initialization code.
     */
    private final static SendableChooser autonChooser = new SendableChooser();
    public void robotInit() {
        SmartDashboard.putNumber("shoot delay", 1.5);            
        //SmartDashboard.putNumber("Target Speed", 3500);
        autonChooser.addDefault("Back Leg Of Pyramid", new BackLegAutonGroup());
        autonChooser.addObject("Front Leg Of Pyramid", new FrontLegAutonGroup());
        autonChooser.addObject("Back Bar Of Pyramid", new BackBarAutonGroup());
            SmartDashboard.putNumber("ramp", 0.0007);
        SmartDashboard.putData("autonChooser", autonChooser);
    }

    public void autonomousInit() {
        ((CommandGroup) autonChooser.getSelected()).start();
        
    }

    /**
     * This function is called periodically during autonomous
     */
    public void autonomousPeriodic() {
        Scheduler.getInstance().run();
    }

    public void disabledInit(){
        Drivetrain.resetEncoders();
    }
    
    public void teleopInit() {
        (new ResetEncodersCommand()).start();
        (new PrintSpeedCommand()).start(); 
        //(new ReadAnglerCalibrationFromFileCommand()).start();
        (new StartCompressorCommand()).start();
    }
    //public Solenoid pawl = new Solenoid(5);
    /**
     * This function is called periodically during operator control
     */
    public void teleopPeriodic() {
        //LiveWindow.run();
        Scheduler.getInstance().run();
        SmartDashboard.putNumber("angle", Angler.controller.getDistance());
            SmartDashboard.putNumber("avgSpeed", Drivetrain.getAvgSpeed());
            SmartDashboard.putNumber("leftSpeed", Drivetrain.getLeftAvgSpeed());
            SmartDashboard.putNumber("rightSpeed", Drivetrain.getRightAvgSpeed());
            SmartDashboard.putNumber("rot Throttle", Drivetrain.getRotationThrottle());
            //Climber.motor.set(OI.operatorStick.getRawAxis(OI.RIGHTY));
        //Angler.motor.set(OI.getRightDriveInput()*OI.getRightDriveInput()*(OI.getRightDriveInput()>0?1:-1));
        //pawl.set(true);
    }
    
    /**
     * This function is called periodically during test mode
     */
    public void testPeriodic() {
        LiveWindow.run();
        Scheduler.getInstance().run();
    }
}
