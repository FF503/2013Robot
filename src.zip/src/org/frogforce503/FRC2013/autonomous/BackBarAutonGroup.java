package org.frogforce503.FRC2013.autonomous;

import edu.wpi.first.wpilibj.command.CommandGroup;
import org.frogforce503.FRC2013.shooter.CheckFrisbeesAndFireCommand;
import org.frogforce503.FRC2013.shooter.GoToPositionCommandGroup;
import org.frogforce503.FRC2013.shooter.ResetNumFrisbeesCommand;
import org.frogforce503.FRC2013.shooter.Shooter.ShooterPosition;


/**
 *
 * @author Bryce Paputa
 */
public class BackBarAutonGroup extends CommandGroup {
    

    public BackBarAutonGroup() {
        addSequential(new AutonStartGroup());
        addSequential(new GoToPositionCommandGroup(ShooterPosition.BACK_BAR));
        addSequential(new ResetNumFrisbeesCommand(5));
        addSequential(new CheckFrisbeesAndFireCommand());
        // Add Commands here:
        // e.g. addSequential(new Command1());
        //      addSequential(new Command2());
        // these will run in order.

        // To run multiple commands at the same time,
        // use addParallel()
        // e.g. addParallel(new Command1());
        //      addSequential(new Command2());
        // Command1 and Command2 will run in parallel.

        // A command group will require all of the subsystems that each member
        // would require.
        // e.g. if Command1 requires chassis, and Command2 requires arm,
        // a CommandGroup containing them would require both the chassis and the
        // arm.
    }
}
